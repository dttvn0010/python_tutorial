from flask import Flask, render_template, request, flash, redirect, url_for
import sqlite3 as sql

app = Flask(__name__)
app.config['SECRET_KEY'] = "abcxyztuv"
   
@app.route('/new', methods = ['GET', 'POST'])
def addnew():
    
    if request.method == 'POST':
        try:
            nm = request.form['nm']
            addr = request.form['add']
            city = request.form['city']
            pin = request.form['pin']

            with sql.connect("database.db") as con:
                cur = con.cursor()            
                cur.execute("INSERT INTO students (name,addr,city,pin)VALUES (?,?,?,?)", (nm, addr, city, pin))
                con.commit()        
                flash('Record was successfully added')        
                return redirect(url_for('show_all')) 
                
        except Exception as e:
            flash(str(e), 'error')
            con.rollback()
        finally:        
            con.close()
            
    return render_template('new.html')
         
@app.route('/')
def show_all():
    con = sql.connect("database.db")
    con.row_factory = sql.Row

    cur = con.cursor()
    cur.execute("select * from students")

    rows = cur.fetchall(); 
    return render_template("show_all.html",rows = rows)
   
if __name__ == '__main__':
   app.run(debug = True)