from flask import Flask

app = Flask(__name__)

DB_NAME = 'database.db'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + DB_NAME
app.config['SECRET_KEY'] = "abcxyztuv"
