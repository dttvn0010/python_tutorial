import sqlite3 as sql
from config import DB_NAME

def getAllStudents():
    con = sql.connect(DB_NAME)
    con.row_factory = sql.Row

    cur = con.cursor()
    cur.execute("select * from student")

    return cur.fetchall(); 

def getStudentById(id):
    con = sql.connect(DB_NAME)
    con.row_factory = sql.Row

    cur = con.cursor()
    cur.execute("select * from student where id=?", (id,))
    
    return cur.fetchone()

def createStudent(student_no, student_name, address):
    try:
        with sql.connect(DB_NAME) as con:
            cur = con.cursor()  
            cur.execute("INSERT INTO student (student_no,student_name,address)VALUES (?,?,?)", 
                            (student_no, student_name, address))
            con.commit()

    except Exception:        
        con.rollback()
        raise
    finally:        
        con.close()

def updateStudent(id, student_no, student_name, address):
    try:
        with sql.connect(DB_NAME) as con:
            cur = con.cursor()  
            cur.execute("UPDATE student SET student_no=?,student_name=?,address=? WHERE id=?", 
                            (student_no, student_name, address, id))
            con.commit()

    except Exception:        
        con.rollback()
        raise
    finally:        
        con.close()
        
def deleteStudent(id):
    try:
        with sql.connect(DB_NAME) as con:
            cur = con.cursor()  
            cur.execute("DELETE FROM student WHERE id=?", (id,))                            
            con.commit()

    except Exception:        
        con.rollback()
        raise
    finally:        
        con.close()
