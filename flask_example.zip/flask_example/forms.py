import db_service

class StudentForm():

    def __init__(self, request=None, dbModel=None):
            
        if request:
            self.student_id = request.form['student_id']
            self.student_no = request.form['student_no']
            self.student_name = request.form['student_name']
            self.address = request.form['address']
            
        elif dbModel:
            self.student_id = dbModel.id
            self.student_no = dbModel.student_no
            self.student_name = dbModel.student_name
            self.address = dbModel.address
        
                
    def validate(self):
        errorList = []
        
        if not self.student_no:
            errorList.append('Student number is required')
            
        if not self.student_name:
            errorList.append('Student name is required')
            
        if not self.address:
            errorList.append('Address is required')
            
        return errorList
            
    def save(self):
        if self.student_id:
            db_service.updateStudent(self.student_id, self.student_no, self.student_name, self.address)
        else:
            db_service.createStudent(self.student_no, self.student_name, self.address)