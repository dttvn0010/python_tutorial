from flask import Flask, render_template, request, redirect, url_for
import traceback

from forms import StudentForm
from config import app
import db_service2 as db_service

app.config['SECRET_KEY'] = "abcxyztuv"

@app.route('/student/add_edit/<int:student_id>', methods = ['GET', 'POST'])
def add_edit_student(student_id):
    errorList = []
    form = StudentForm()
    
    if request.method == 'POST':
        try:
            form = StudentForm(request)
            errorList = form.validate()
            
            if not errorList:
                form.save()
                return redirect(url_for('list_student'))
                
        except Exception as e:
            traceback.print_exc()
            errorList.append(str(e))
            
    elif student_id > 0:
        student = db_service.getStudentById(student_id)
        form = StudentForm(dbModel=student)
    
    return render_template('add_edit_student.html', form=form, errorList=errorList)
    
@app.route('/student/delete/<int:student_id>')
def delete_student(student_id):
    try:
        db_service.deleteStudent(student_id)
    except Exception:
        traceback.print_exc()        

    return redirect(url_for('list_student'))

@app.route('/')
def list_student():
    student_list = db_service.getAllStudents()
    return render_template("list_student.html", student_list=student_list)
   
if __name__ == '__main__':
   app.run(debug = True)
