from flask_sqlalchemy import SQLAlchemy
from config import app

db = SQLAlchemy(app)

class Student(db.Model):
    id = db.Column(db.Integer, primary_key = True)
    student_no = db.Column(db.String(20), unique=True)
    student_name = db.Column(db.String(50))
    address = db.Column(db.String(50))
   
    def __init__(self, student_no, student_name, address):
        self.student_no = student_no
        self.student_name = student_name
        self.address = address

def getAllStudents():
    return Student.query.all()

def getStudentById(id):
    return Student.query.get(id)

def createStudent(student_no, student_name, address):
    student = Student(student_no, student_name, address)
    db.session.add(student)
    db.session.commit()

def updateStudent(id, student_no, student_name, address):
    student = Student.query.get(id)
    student.student_no = student_no
    student.student_name = student_name
    student.address = address
    db.session.commit()
        
def deleteStudent(id):
    student = Student.query.get(id)
    db.session.delete(student)
    db.session.commit()

db.create_all()