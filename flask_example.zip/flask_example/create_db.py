import sqlite3
from config import DB_NAME

conn = sqlite3.connect(DB_NAME)
print("Opened database successfully")

conn.execute('''CREATE TABLE student (
                id INTEGER PRIMARY KEY, 
                student_no VARCHAR(20) UNIQUE, 
                student_name VARCHAR(50), 
                address VARCHAR(100))''')
                
print("Table created successfully")
conn.close()
